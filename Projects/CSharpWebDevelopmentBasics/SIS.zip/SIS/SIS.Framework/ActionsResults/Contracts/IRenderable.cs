﻿namespace SIS.Framework.ActionsResults.Contracts
{
    public interface IRenderable
    {
        string Render();
    }
}
