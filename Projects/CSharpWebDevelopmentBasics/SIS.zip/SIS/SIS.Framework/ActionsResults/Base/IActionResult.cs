﻿namespace SIS.Framework.ActionsResults.Base
{
    public interface IActionResult
    {
        string Invoke();
    }
}
